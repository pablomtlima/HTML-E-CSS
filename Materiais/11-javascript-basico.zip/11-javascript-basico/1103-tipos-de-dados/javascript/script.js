let total = 0;

const compras = 30;
const imposto = 10;

total = compras + imposto;

const dobro = total * 2;
const dividir = total / 2;
const desconto = total - 30;

const strings = "20" + "20";
const numbers = 20 + 20;

const transformar = Number("20") + 20;

console.log(20.332325);
